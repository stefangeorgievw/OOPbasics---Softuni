﻿using System;
using System.Collections.Generic;
using System.Text;


public class Car : Vehicle
{
    public Car(double fuelQuantity, double fuelConsumptionPerKm, double airConditioningConsumption,double tankCapacity) : base(fuelQuantity, fuelConsumptionPerKm, airConditioningConsumption,tankCapacity)
    {

    }
}

