﻿using System;


public class Program
{
    static void Main(string[] args)
    {
        StackOfStrings stack = new StackOfStrings();
        stack.Push("stefko");
        Console.WriteLine(stack.Peek());
        Console.WriteLine(stack.Pop());
    }
}

